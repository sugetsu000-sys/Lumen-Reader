LUMEN READER - PROTOTIPE ANDROID
================================

ISI PAKET
- app/src/main/assets/index.html : antarmuka dan mesin pembaca prototipe
- app/src/main/java/.../MainActivity.java : pembungkus Android WebView dan pemilih file
- app/build.gradle : konfigurasi modul Android

CARA MEMBUKA DI ANDROID STUDIO
1. Ekstrak ZIP ini di komputer.
2. Buka folder LumenReader sebagai project di Android Studio.
3. Pastikan Android SDK Platform 36 terpasang.
4. Jalankan Gradle Sync. Android Studio akan mengunduh dependensi yang dibutuhkan.
5. Hubungkan perangkat Android atau pilih emulator, lalu tekan Run.
6. Untuk membuat APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

CATATAN
- Ini adalah source project, bukan APK yang sudah dikompilasi.
- Proyek ini belum dapat dikompilasi di lingkungan pembuat karena Android SDK tidak tersedia.
- Aplikasi tidak menampilkan iklan dan tidak meminta akun.
- PDF.js dan JSZip dimuat dari CDN, jadi koneksi internet dibutuhkan untuk memuat mesin file.
- Terjemahan memakai API MyMemory. Teks yang dipilih/dikirim akan keluar dari perangkat menuju layanan tersebut. Penggunaan gratis memiliki batas harian.
- Format prototipe: PDF, EPUB, DOCX, ODT, FB2, TXT, RTF, HTML, dan Markdown.
- MOBI, AZW3, DJVU, DOC lama, dan arsip komik belum didukung.
- PDF scan tanpa teks belum bisa OCR. Dokumen Word/ODT kompleks dapat kehilangan sebagian tata letak atau gambar.
